//
//  Book.swift
//  bookApi
//
//  Created by Humeira on 25.04.2019.
//  Copyright © 2019 Humeira. All rights reserved.
//


import UIKit

class Book: NSObject {
    var title:String?
    var author:String?
    var imageURL:String?
    var publishDate:String?
    var descriptionInfo:String?
    var ViewI:String?
}
