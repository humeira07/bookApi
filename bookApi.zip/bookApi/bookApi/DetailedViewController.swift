//
//  DetailedViewController.swift
//  bookApi
//
//  Created by Humeira on 25.04.2019.
//  Copyright © 2019 Humeira. All rights reserved.
//

import UIKit

class DetailedViewController: UIViewController {
    
    var book: Book?

    @IBOutlet weak var ViewI: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var publishedDateLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        guard let book = book else { return }
        
        titleLabel.text = book.title
        descriptionLabel.text = book.descriptionInfo
        publishedDateLabel.text = book.publishDate
        ViewI.contentMode = .scaleAspectFit
        ViewI.imageFromURL(urlString:
            book.ViewI!)

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func goBackButtonPressed(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
