//
//  ViewController.swift
//  bookApi
//
//  Created by Humeira on 25.04.2019.
//  Copyright © 2019 Humeira. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var tableView: UITableView!
    
    var books = [Book]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        searchBar.delegate = self
        tableView.delegate = self
        tableView.dataSource = self
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func getBooks(query:String){
        let query = query.addingPercentEncoding(withAllowedCharacters:
        .urlQueryAllowed)!
        
        let url = "https://www.googleapis.com/books/v1/volumes?q=\(query)"
        
        URLSession.shared.dataTask(with: URL(string: url)!){(data, response, error)
            in if (error != nil) {
                print(error?.localizedDescription ?? "")
            } else {
            let json = try! JSONSerialization.jsonObject(with: data!, options:
                .allowFragments) as! [String: AnyObject]
                
                if let items = json["items"] as? [[String: AnyObject]] {
                    print("got items", items)
                    
                    self.books = []
                    for item in items {
                        if let volumeInfo = item["volumeInfo"] as? [String: AnyObject]{
                            let book = Book()
                            book.title = volumeInfo["title"] as? String
                            book.publishDate = volumeInfo["publishDate"] as? String
                            book.descriptionInfo = volumeInfo["description"] as? String
                            
                            if let authors = volumeInfo["authors"] as? [String] {
                                var creators = " "
                                for author in authors {
                                    creators += author
                                }
                                book.author = creators
                            }
                            if let imageLinks = volumeInfo["imageLinks"] as? [String: String]{
                                book.imageURL = imageLinks["smallThumbnail"]
                                book.ViewI = imageLinks["thumbnail"]
                            }
                            self.books.append(book)
                        }
                    }
                    DispatchQueue.main.async {
                        self.tableView.reloadData()
                    }
                }
                
            }
        }.resume()
    }
 
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        if segue.identifier == "detailBook" {
            if let toViewBookController = segue.destination as? DetailedViewController{
            if let indexPath = tableView.indexPathForSelectedRow {
                toViewBookController.book = books[indexPath.row]
            }
        }
    }
}
   
}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.books.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath) as! TableViewCell
        
        cell.titleLabel.text = books[indexPath.row].title!
        cell.authorLabel.text = books[indexPath.row].author
        
        
        if let imageHaveUrl = books[indexPath.row].imageURL {
            cell.coverImageView.contentMode = .scaleAspectFit
            cell.coverImageView.imageFromURL(urlString: imageHaveUrl)
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "detailBook", sender: self)
    }
    
}
extension UIImageView {
    public func imageFromURL(urlString: String){
        if let url = URL(string: urlString) {
            URLSession.shared.dataTask(with: url, completionHandler: { (data, response, error)
                in if error != nil {
                    print(error?.localizedDescription as Any)
                } else {
                    if let image = UIImage(data: data!) {
                        DispatchQueue.main.async {
                            self.image = image
                        }
                    }
                }
            }).resume()
        }
    }
}

extension ViewController: UISearchBarDelegate {
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        if searchBar.text != nil && !(searchBar.text?.isEmpty)! {
            let text = searchBar.text
            getBooks(query: text!)
        }
    }
}

